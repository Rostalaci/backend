
const express = require("express");
const mysql = require("mysql2/promise");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());



const zenekarok = require("../../db/rock_zenekarok_70s.json");

app.get("/api/zenekar", function(req, res) {
    res.json(zenekarok);
});

app.listen(PORT, function() {
    console.log(`A szerver fut: http://localhost:${PORT}`);
});

app.listen(3000, function() {
    console.log("Backend fut a 3000-es porton!");
});


